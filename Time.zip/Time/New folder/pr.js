
// let time= new Date();

// let tm = time.getTime();
// let dat = time.getDate()
// let day = time.getDay()
// let getMonth = time.getMonth()
// let hours = time.getHours()
// let mnt = time.getMinutes()
// let sec = time.getSeconds()
// let getMs = time.getMilliseconds()
// let year = time.getFullYear()

// document.write(year);

let hours = document.getElementById('hours')
let minet = document.getElementById('minet')
let sec = document.getElementById('sec')
let ampm = document.getElementById('ampm')

 setInterval(function(){
    let time = new Date()
    let hrs = time.getHours()
    let min = time.getMinutes()
    let sc = time.getSeconds()

    if(hrs<=12){
       ampm.innerHTML='PM'
    }else{
        ampm.innerHTML='AM'
    }

    hrs = (hrs>12) ? hrs-12:hrs

    hrs = (hrs<10) ? "0"+hrs:hrs;
    min = (min<10) ? "0"+min:min;
    sc = (sc<10) ? "0"+sc:sc;

    hours.innerHTML=hrs
    minet.innerHTML=min
    sec.innerHTML=sc

 })